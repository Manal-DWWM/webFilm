<?php
//On affiche le template Twig correspondant
echo $twig->render('footer.html.twig');
