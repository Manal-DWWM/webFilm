<?php
//On affiche le template Twig correspondant
echo $twig->render('header.html.twig');
